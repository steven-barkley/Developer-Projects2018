Thank you for downloading the Mapbox Unity SDK (for Unity 2017.1+)! 


Getting started: https://www.mapbox.com/mapbox-unity-sdk/docs/00-getting-started.html

Configuring your API token: https://www.mapbox.com/mapbox-unity-sdk/docs/01-mapbox-api-token.html

Tutorials: https://www.mapbox.com/unity-sdk/tutorials/

Built-in Examples: https://www.mapbox.com/mapbox-unity-sdk/docs/03-examples.html

Known Issues: https://www.mapbox.com/mapbox-unity-sdk/docs/02-known-issues.html

Attribution: https://www.mapbox.com/mapbox-unity-sdk/docs/04-attribution.html

API: https://www.mapbox.com/mapbox-unity-sdk/api/



Current version: 1.2.0, as of 09/26/2017

Changelog: https://www.mapbox.com/mapbox-unity-sdk/docs/05-changelog.html

IMPORTANT: 
If you intend to deploy for Android, please set your minimum version to 15 in PlayerSettings.
For iOS, please set your minimum version to 8.

If you have any other issues or feedback, please contact us at https://www.mapbox.com/contact/ 
or check our public repository: https://github.com/mapbox/mapbox-unity-sdk/issues.