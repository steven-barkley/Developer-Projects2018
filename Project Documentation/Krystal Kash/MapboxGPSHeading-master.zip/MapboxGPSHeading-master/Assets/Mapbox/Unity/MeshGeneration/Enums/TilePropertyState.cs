namespace Mapbox.Unity.MeshGeneration.Enums
{
    public enum TilePropertyState
    {
        None,
        Loading,
        Loaded,
        Error,
		Cancelled,
	}
}
