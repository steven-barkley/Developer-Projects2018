﻿namespace Mapbox.Unity.Location
{
	using System.Collections;
	using UnityEngine;

	public abstract class AbstractEditorLocationProvider : AbstractLocationProvider
	{
		[SerializeField]
		protected int _accuracy;

		[SerializeField]
		bool _autoFireEvent;

		[SerializeField]
		float _updateInterval;

		[SerializeField]
		bool _sendEvent;

		protected Location _currentLocation;

		WaitForSeconds _wait;

#if UNITY_EDITOR
		void Awake()
		{
			_wait = new WaitForSeconds(_updateInterval);
			StartCoroutine(QueryLocation());
		}
#endif

		IEnumerator QueryLocation()
		{
			while (true)
			{
				SetLocation();
				if (_autoFireEvent)
				{
					SendLocation(_currentLocation);
				}
				yield return _wait;
			}
		}

		public void SendLocationEvent()
		{
			SetLocation();
			SendLocation(_currentLocation);
		}

		void OnValidate()
		{
			if (_sendEvent)
			{
				_sendEvent = false;
				SendLocationEvent();
			}
		}

		protected abstract void SetLocation();
	}
}