﻿using UnityEngine;

namespace Mapbox.Examples.Voxels
{
	public class VoxelData
	{
		public Vector3 Position;
		public GameObject Prefab;
	}
}
