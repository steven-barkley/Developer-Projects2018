Thanks for downloading the GameSparks Unity plugin! Get ready to explore everything the platform has to offer, from its rich feature set, absolute flexibility and rapid support system. 

Before using this asset, you must register for the GameSparks platform by following this link:
https://auth.gamesparks.net/register.htm 

To jump-start development, we recommend you begin with our 'Getting Started' guide on our knowledge resource GameSparks Learn+:
https://docs2.gamesparks.com/getting-started/creating-a-game/unity-setup.html

Should any problems arise, our support team are always on hand to get you back on track. You can also engage with the GameSparks community on our forums:
https://support.gamesparks.net/helpdesk

We hope you build engagement and sustain success with GameSparks! 
The GameSparks team
